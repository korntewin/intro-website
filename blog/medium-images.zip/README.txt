ML Prediction Service blog images for Medium

The files are numbered in article reading order. Upload each PNG into the corresponding position in a Medium draft. Upload one at a time if you want to avoid Medium arranging them as a grid.

Source: https://korntewin.github.io/intro-website/blog/riir-rust-prediction-service/
